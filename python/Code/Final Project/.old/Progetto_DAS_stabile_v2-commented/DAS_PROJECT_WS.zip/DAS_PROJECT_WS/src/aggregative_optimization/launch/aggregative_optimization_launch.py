# This code creates a launch file for a ROS 2 simulation of an aggregative optimization problem with multiple agents.

# Import necessary libraries
from launch import LaunchDescription # LaunchDescription for ROS 2
from launch_ros.actions import Node # Node for ROS 2 nodes
import numpy as np # NumPy for numerical operations
import networkx as nx # NetworkX for graph operations
from scipy import sparse  # SciPy for sparse matrix operations

class Agent_Config:
    """ Configuration of attributs for an agent in the aggregative optimization problem. """
    def __init__(self, id, position):
        """Initialize an agent with an identifier and initial position and other attributes set to None or empty.
        Args:               
            id (int): Identifier for the agent.
            position (list or np.array): Initial position of the agent in 2D space.
        """
        self.id = int(id)  # Identifier for the agent. Ensure it's an integer. 
        self.position = np.array(position, dtype=float).astype(float) # Current position of the agent (z_i). Force float64->float
        self.target = None # Private target (r_i)
        self.state = None # Current state estimate of the agent (z_i)
        self.sigma_estimate = np.array([], dtype=float).astype(float) # Current stimate of σ(z) (s_i)
        self.v_estimate = np.array([]) # Current estimate of (1/N)*∑∇₂ℓ_j(z_j,σ) (v_i)
        self.neighbors = [] # Communication neighbors
        self.weights = {} # Adjacency matrix weights for the agent i related to its neighbors (including itself) 
        self.history = [] # Position history for animation
        self.gamma = 1.0 # Tradeoff parameter for the local cost function (γ_i)
        self.dimension = None # Robot position variable dimension (2D space)

    def set_target(self, target_position):
        """Set the private target position for the agent.
        Args:
            target_position (list or np.array): Target position (r_i) for the agent.
        """
        self.target = np.array(target_position, dtype=float) # Position of the target (r_i)

    def set_gamma(self, gamma):
        """Set the gamma value for the agent.
        Args:
            gamma (float): Tradeoff parameter for the local cost function.
        """
        self.gamma = gamma # Tradeoff parameter for the local cost function (γ_i)

class AggregativeSetup:
    """ Setup for the aggregative optimization problem with agent inizialization and communication graph creation. """
    def __init__(self, agents, dimension, graph_type='erdos_renyi', p_er=0.8):
        """Initialize agents and create a communication graph.
        Args:
            agents (list): List of Agent_Config instances representing the agents.
            dimension (int): Dimension of the problem space (2D).
            graph_type (str): Type of communication graph to create ('erdos_renyi', 'cycle', 'star', 'path', or 'complete').
            p_er (float): Probability for Erdos-Renyi graph creation (only used if  graph_type is 'erdos_renyi').
        """
        self.agents = agents # List of agents
        self.num_agents = len(agents) # Number of agents
        self.dimension = dimension  # Robot position variable dimension (2D space)
        
        # First ensure all states are properly initialized
        for agent in self.agents: # Iterate through each agent
            agent.state = np.array(agent.position, dtype=float) # Current state (z_i) initialized to the initial agent's position z_i_0
            agent.history = [agent.position.copy()] # Initialize history with the initial position of the agent
            agent.dimension = self.dimension # Robot position variable dimension (2D space)
            # Initialize sigma_estimate and v_estimate as zero arrays for the moment. Then in the agent node they will be initialized properly
            agent.sigma_estimate = np.zeros(self.dimension, dtype=float) 
            agent.v_estimate = np.zeros(self.dimension, dtype=float)
        
        # Create communication graph
        self.create_communication_graph(graph_type, p_er)
    
    def create_communication_graph(self, graph_type, p_er):
        """Create a connected communication graph between agents with a doubly stochastic weighted adjacency matrix
        with Metropolis-Hastings weights.
        Args:
            graph_type (str): Type of communication graph ('erdos_renyi', 'cycle', 'star', 'path', or 'complete').
            p_er (float): Probability for Erdos-Renyi graph generation.
        """
        if graph_type == 'erdos_renyi': # Erdos-Renyi graph
            while True: # Generate a random Erdos-Renyi graph until it is connected
                G = nx.erdos_renyi_graph(self.num_agents, p_er) # Erdos-Renyi graph generation
                if nx.is_connected(G): # Check if the graph is connected
                    break # If connected, exit the loop
            Adj = nx.adjacency_matrix(G).toarray() # Get adjacency matrix of the graph (no self-loops)
        elif graph_type == 'cycle': # Cycle graph
            G = nx.cycle_graph(self.num_agents) # Cycle graph generation
            Adj = nx.adjacency_matrix(G).toarray() # Get adjacency matrix of the graph (no self-loops)
        elif graph_type == 'star': # Star graph
            G = nx.star_graph(self.num_agents - 1) # Star graph generation (num_agents - 1 because the center node is not counted)
            Adj = nx.adjacency_matrix(G).toarray() # Get adjacency matrix of the graph (no self-loops)
        elif graph_type == 'path': # Path graph
            G = nx.path_graph(self.num_agents) # Path graph generation
            Adj = nx.adjacency_matrix(G).toarray() # Get adjacency matrix of the graph (no self-loops)
        else: # Complete graph
            G = nx.complete_graph(self.num_agents) # Complete graph generation
            Adj = nx.adjacency_matrix(G).toarray() # Get adjacency matrix of the graph (no self-loops)
        
        # Metropolis-Hastings weights method for generating doubly stochastic weighted adjacency matrix
        degrees = np.sum(Adj, axis=1) # Degree of each agent (number of neighbors). Array of shape (num_agents,) with the degree of each agent.  
        A = np.zeros((self.num_agents, self.num_agents)) # Initialize weighted adjacency matrix with zeros
        for i in range(self.num_agents): # Iterate over each agent
            neighbors = np.nonzero(Adj[i])[0] # Get neighbors (indices) of agent i (non-zero entries in row i of the adjacency matrix). Note that this does not include self-loops.
            for j in neighbors: # Iterate over each neighbor of agent i
                if i < j: # Ensure each edge is processed only once
                    max_deg = max(degrees[i], degrees[j]) # Maximum degree of the two agents
                    weight = 1 / (1 + max_deg) # Metropolis-Hastings weight
                    A[i, j] = weight # Assign weight to the adjacency matrix
                    A[j, i] = weight # Assign weight to the adjacency matrix (symmetric)
            A[i, i] = 1 - np.sum(A[i, :]) # Assign self-loop weight to ensure row sums to 1
        
        self.A = A # Store the weighted adjacency matrix
        
        # Store neighbors and weights of each agent
        for i, agent in enumerate(self.agents): # Iterate through each agent
            agent.neighbors = list(np.nonzero(Adj[i])[0]) # Get neighbors (indices) of agent i (non-zero entries in row i of the adjacency matrix). Note that this does not include self-loops.
            agent.weights = {int(j): float(A[i, j]) for j in agent.neighbors}  # Get weights of agent i's neighbors from the weighted adjacency matrix
            agent.weights[int(i)] = float(A[i, i])  # Get self-loop weight for agent i

def generate_launch_description():
    """Generate the launch description for the aggregative optimization problem simulation.
    Returns:
        LaunchDescription: A ROS 2 launch description containing the nodes for each agent and the visualization node.
    """
    np.random.seed(42) # Set random seed for reproducibility
    dimension = 2  # Problem dimension (2D space)
    num_agents = 8 # Number of agents
    area_size = 10 # Area size of the problem (area_size x area_size square)

    step_size = 0.01 # Step size for the optimization algorithm
    MAXITERS = 977 # Maximum number of iterations for the optimization algorithm
    COMM_TIME = 1e-1  # communication time period

    # Create agents with random initial positions within the area size
    agents = [Agent_Config(i, np.random.uniform(0, area_size, size=2)) for i in range(num_agents)]
    
    # Assign private targets
    for agent in agents: # Iterate through each agent
        agent.set_target(np.random.uniform(0, area_size, size=2)) # Set a random target position (r_i) for each agent
    
    # Set different gamma values
    for i, agent in enumerate(agents): # Iterate through each agent
        # agent.set_gamma(0.3 + 0.7 * (i % 2))  # Alternate between 0.3 and 1.0
        agent.set_gamma(1.0)  # # Set gamma (γ_i) for each agent 

    AggregativeSetup(agents, dimension, graph_type='cycle') # Simulation Setup (agent initialization and communication graph creation)

    node_list = []  # List to hold the nodes for each agent and the visualization node
    package_name = "aggregative_optimization" # Package name containing the ROS 2 nodes (agent node and visualization node)

    for i, agent in enumerate(agents): # Iterate through each agent
        node_list.append( # Create a node for each agent
            Node(
                package=package_name,  # Package name containing the ROS 2 nodes (agent node and visualization node)
                namespace=f"agent_{i}", # Namespace for the agent node
                executable="generic_agent", # Executable name for the agent node contained in the setup.py file
                parameters=[ # Parameters for the agent node passed as a list of dictionaries from the Agent_Config class
                    {
                        "id": int(agent.id),  # Agent identifier. Convert numpy.int64 to int 
                        "position": [float(x) for x in agent.position], # Initial position of the agent (z_i_0). Convert numpy.float to float
                        "target": [float(x) for x in agent.target], # Private target position (r_i). Convert numpy.float to float
                        "state": [float(x) for x in agent.state], # Current state estimate of the agent (z_i). Convert numpy.float to float
                        "sigma_estimate": [float(x) for x in agent.sigma_estimate], # Current estimate of σ(z) (s_i). Convert numpy.float to float
                        "v_estimate": [float(x) for x in agent.v_estimate], # Current estimate of (1/N)*∑∇₂ℓ_j(z_j,σ) (v_i). Convert numpy.float to float
                        "neighbors": [int(n) for n in agent.neighbors],  # Communication neighbors (list of agent ids). Convert numpy.int64 to int
                        "weights": [item for pair in agent.weights.items() for item in (int(pair[0]), float(pair[1]))], # Adjacency matrix weights for the agent i related to its neighbors (including itself). Convert numpy.int64 to int and numpy.float to float
                        "gamma": float(agent.gamma), # Tradeoff parameter for the local cost function (γ_i). Convert numpy.float to float
                        "dimension": int(agent.dimension), # Robot position variable dimension (2D space). Convert numpy.int64 to int
                        "communication_time": COMM_TIME, # Communication time period
                        "maxT": MAXITERS, # Maximum number of iterations for the optimization algorithm
                        "step_size": step_size, # Step size for the optimization algorithm
                    }
                ],
                output="screen", # Output to screen. This will print the output of the agent node to the terminal
                prefix=f'xterm -title "agent_{i}" -fg white -bg black -fs 12 -fa "Monospace" -hold -e', # Launch the node in a separate terminal window with custom appearance and behavior
            )
        )

    node_list.append( # Add the visualization node to the node list
        Node(
            package=package_name, # Package name containing the ROS 2 nodes (agent node and visualization node)
            executable='visualization_node', # Executable name for the visualization node contained in the setup.py file
            output='screen' # Output to screen. This will print the output of the visualization node to the terminal
        )
    )

    return LaunchDescription(node_list) # Return the launch description containing all the nodes