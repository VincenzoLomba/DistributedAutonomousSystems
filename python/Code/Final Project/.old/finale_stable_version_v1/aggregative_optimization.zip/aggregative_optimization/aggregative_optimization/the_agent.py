import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray as MsgFloat
import time
from typing import Dict, List, Optional

class Agent(Node):
    def __init__(self):
        super().__init__(
            "aggregative_optimization_agent",
            allow_undeclared_parameters=True,
            automatically_declare_parameters_from_overrides=True,
        )

        # Get and validate parameters
        self.id = int(self.get_parameter("id").value)
        self.dimension = int(self.get_parameter("dimension").value)
        self.gamma = float(self.get_parameter("gamma").value)
        self.communication_time = float(self.get_parameter("communication_time").value)
        self.maxT = int(self.get_parameter("maxT").value)
        self.step_size = float(self.get_parameter("step_size").value)
        self.max_wait_cycles = 5  # Max cycles to wait for late messages

        # State initialization
        self.position = self._safe_array_conversion("position", self.dimension)
        self.target = self._safe_array_conversion("target", self.dimension)
        self.state = self._safe_array_conversion("state", self.dimension)
        self.sigma_estimate = self.phi_i(self.state)  # Initialize with phi_i(z_i)
        self.v_estimate = self.gradient_2_cost(self.state, self.sigma_estimate)  # Initialize with ∇₂ℓ
        
        # Communication setup
        self.neighbors = [int(n) for n in self.get_parameter("neighbors").value]
        self.weights = self._process_weights()
        self._setup_communication()

        # Tracking variables
        self.k = 0
        self.wait_cycles = 0
        self.last_received_iter = {j: -1 for j in self.neighbors}
        self.received_messages: Dict[int, Dict[int, List[float]]] = {}  # {neighbor: {iter: data}}
        self.last_known_state: Dict[int, np.ndarray] = {}  # Track neighbors' last state
        self.last_known_sigma: Dict[int, np.ndarray] = {}  # Track neighbors' last sigma
        self.last_known_v: Dict[int, np.ndarray] = {}  # Track neighbors' last v

    def _safe_array_conversion(self, param_name: str, expected_length: int) -> np.ndarray:
        """Convert parameter to numpy array with validation."""
        param_value = self.get_parameter(param_name).value
        if not isinstance(param_value, list) or len(param_value) != expected_length:
            raise ValueError(f"Invalid {param_name} parameter")
        return np.array([float(x) for x in param_value], dtype=float)

    def _process_weights(self) -> Dict[int, float]:
        """Process weights into neighbor->weight mapping."""
        weights_list = self.get_parameter("weights").value
        weights = {
            int(weights_list[i]): float(weights_list[i+1]) 
            for i in range(0, len(weights_list), 2)
        }
        weights.setdefault(self.id, 1.0 - sum(w for j, w in weights.items() if j != self.id))
        return weights

    def _setup_communication(self):
        """Initialize all communication channels."""
        self.publisher = self.create_publisher(MsgFloat, f"/topic_{self.id}", 10)
        
        for j in self.neighbors:
            self.create_subscription(
                MsgFloat,
                f"/topic_{j}",
                lambda msg, j=j: self.listener_callback(msg, j),
                10
            )

        self.vis_publisher = self.create_publisher(MsgFloat, '/visualization_data', 10)
        self.timer = self.create_timer(self.communication_time, self.timer_callback)

    def listener_callback(self, msg: MsgFloat, neighbor_id: int):
        """Store messages with iteration tracking."""
        msg_iter = int(msg.data[0])
        data = list(msg.data[1:])
        
        # Update last known values
        self.last_known_state[neighbor_id] = np.array(data[:self.dimension])
        self.last_known_sigma[neighbor_id] = np.array(data[self.dimension:2*self.dimension])
        self.last_known_v[neighbor_id] = np.array(data[2*self.dimension:3*self.dimension])
        
        # Store by iteration
        if neighbor_id not in self.received_messages:
            self.received_messages[neighbor_id] = {}
        self.received_messages[neighbor_id][msg_iter] = data

    def timer_callback(self):
        """Main optimization loop with sync checks."""
        if self.k == 0:
            self._publish_state()
            self.k += 1
            return

        # Check for k-1 messages
        expected_iter = self.k - 1
        ready, missing = self._check_messages_ready(expected_iter)
        
        if not ready:
            self.wait_cycles += 1
            if self.wait_cycles <= self.max_wait_cycles:
                if self.wait_cycles == 1:
                    self.get_logger().debug(
                        f"Agent {self.id} waiting for {missing} (cycle {self.wait_cycles}/{self.max_wait_cycles})"
                    )
                return
            else:
                self.get_logger().warning(
                    f"Agent {self.id} proceeding without {missing} after {self.max_wait_cycles} waits"
                )

        # Reset waiting counter if proceeding
        self.wait_cycles = 0
        
        try:
            self._optimization_step(expected_iter)
            self._publish_state()
            self._publish_visualization_data()
            self.k += 1
        except Exception as e:
            self.get_logger().error(f"Optimization error: {str(e)}")
            raise

        # Clear old messages (keep only current and previous iter)
        for j in self.neighbors:
            if j in self.received_messages:
                keep_iters = [self.k, self.k-1]
                self.received_messages[j] = {
                    k: v for k, v in self.received_messages[j].items() 
                    if k in keep_iters
                }

        if self.k > self.maxT:
            self._terminate()

    def _check_messages_ready(self, expected_iter: int) -> tuple[bool, list[int]]:
        """Check if all neighbors have messages for expected_iter."""
        missing = []
        for j in self.neighbors:
            if j not in self.received_messages or expected_iter not in self.received_messages[j]:
                missing.append(j)
        return (len(missing) == 0, missing)

    def _optimization_step(self, expected_iter: int):
        """Synchronous optimization step using k-1 data."""
        prev_state = self.state.copy()
        prev_sigma = self.sigma_estimate.copy()

        # Collect neighbor data from expected_iter or last known
        neighbor_data = {}
        for j in self.neighbors:
            if j in self.received_messages and expected_iter in self.received_messages[j]:
                neighbor_data[j] = self.received_messages[j][expected_iter]
            else:
                # Fallback to last known values
                neighbor_data[j] = [
                    *self.last_known_state.get(j, np.zeros(self.dimension)),
                    *self.last_known_sigma.get(j, np.zeros(self.dimension)),
                    *self.last_known_v.get(j, np.zeros(self.dimension)),
                ]

        # State update
        grad_term = (
            self.gradient_1_cost(self.state, self.sigma_estimate) + 
            self.gradient_phi(self.state) @ self.v_estimate
        )
        self.state -= self.step_size * grad_term
        self.position = self.state.copy()

        # Sigma estimate update (sync with task_2_v3)
        new_sigma = self.weights[self.id] * self.sigma_estimate
        for j in self.neighbors:
            j_sigma = np.array(neighbor_data[j][self.dimension:2*self.dimension])
            new_sigma += self.weights[j] * j_sigma
        new_sigma += self.phi_i(self.state) - self.phi_i(prev_state)
        self.sigma_estimate = new_sigma

        # V estimate update (sync with task_2_v3)
        new_v = self.weights[self.id] * self.v_estimate
        for j in self.neighbors:
            j_v = np.array(neighbor_data[j][2*self.dimension:3*self.dimension])
            new_v += self.weights[j] * j_v
        new_v += (
            self.gradient_2_cost(self.state, self.sigma_estimate) - 
            self.gradient_2_cost(prev_state, prev_sigma)
        )
        self.v_estimate = new_v

    def _publish_state(self):
        """Publish current state to neighbors."""
        msg = MsgFloat()
        msg.data = [float(self.k), *self.state, *self.sigma_estimate, *self.v_estimate]
        self.publisher.publish(msg)

    def _publish_visualization_data(self):
        """Publish visualization data."""
        vis_msg = MsgFloat()
        vis_msg.data = [
            float(self.id), 
            float(self.k),
            *self.position,
            *self.state,
            *self.sigma_estimate,
            *self.v_estimate,
            *self.target,
            float(self.cost_function(self.state, self.sigma_estimate)),
            float(np.linalg.norm(
                self.gradient_1_cost(self.state, self.sigma_estimate) +
                self.gradient_phi(self.state) @ self.v_estimate
            ))
        ]
        self.vis_publisher.publish(vis_msg)

    def _terminate(self):
        """Handle termination."""
        final_msg = MsgFloat()
        final_msg.data = [-1.0, float(self.k)]
        self.vis_publisher.publish(final_msg)
        self.get_logger().info(f"Agent {self.id} completed optimization")
        time.sleep(3)
        raise SystemExit

    # Original mathematical functions remain unchanged
    def phi_i(self, z_i): return np.array(z_i, dtype=float)
    def cost_function(self, z_i, sigma): return self.gamma * np.linalg.norm(z_i - self.target)**2 + np.linalg.norm(sigma - z_i)**2
    def gradient_1_cost(self, z_i, sigma): return 2 * self.gamma * (z_i - self.target) + 2 * (z_i - sigma)
    def gradient_2_cost(self, z_i, sigma): return 2 * (sigma - z_i)
    def gradient_phi(self, z_i): return np.eye(self.dimension)

def main(args=None):
    rclpy.init(args=args)
    agent = Agent()
    
    try:
        agent.get_logger().info(f"Agent {agent.id} initializing...")
        time.sleep(1 + agent.id * 0.1)  # Staggered startup
        rclpy.spin(agent)
    except (SystemExit, KeyboardInterrupt):
        agent.get_logger().info("Shutting down...")
    finally:
        agent.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()