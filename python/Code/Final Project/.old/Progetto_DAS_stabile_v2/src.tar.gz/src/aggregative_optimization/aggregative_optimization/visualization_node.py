# visualization_node.py
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray as MsgFloat
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import matplotlib

class VisualizationNode(Node):
    def __init__(self):
        super().__init__('visualization_node')
        
        # Data storage
        self.agent_data = {}  # {agent_id: {position_history: [], target: [], etc.}}
        self.cost_history = []
        self.grad_norm_history = []
        self.sigma_error_history = []
        self.max_iters = 0
        self.num_agents = 0
        self.dimension = 2  # Assuming 2D space
        
        # Subscriber
        self.subscription = self.create_subscription(
            MsgFloat,
            '/visualization_data',
            self.listener_callback,
            10
        )
        
        # Plotting variables
        self.fig = None
        self.animation = None
        
    def listener_callback(self, msg):
        agent_id = int(msg.data[0])
        iteration = int(msg.data[1])
        
        if agent_id == -1:  # Final message
            self.compute_metrics()
            self.visualize_results()
            return
            
        if agent_id not in self.agent_data:
            self.agent_data[agent_id] = {
                'position_history': [],
                'target': None,
                'state_history': [],
                'sigma_history': [],
                'v_history': [],
                'cost_history': [],
                'grad_history': []
            }
            self.num_agents = len(self.agent_data)
        
        # Parse the message data
        idx = 2
        position = np.array(msg.data[idx:idx+self.dimension])
        idx += self.dimension
        state = np.array(msg.data[idx:idx+self.dimension])
        idx += self.dimension
        sigma_estimate = np.array(msg.data[idx:idx+self.dimension])
        idx += self.dimension
        v_estimate = np.array(msg.data[idx:idx+self.dimension])
        idx += self.dimension
        target = np.array(msg.data[idx:idx+self.dimension])
        idx += self.dimension
        cost = msg.data[idx]
        idx += 1
        grad = np.array(msg.data[idx:idx+self.dimension])
        
        # Store data
        agent = self.agent_data[agent_id]
        agent['position_history'].append(position)
        agent['state_history'].append(state)
        agent['sigma_history'].append(sigma_estimate)
        agent['v_history'].append(v_estimate)
        agent['target'] = target
        agent['cost_history'].append(cost)
        agent['grad_history'].append(grad)
    
    def compute_metrics(self):
        max_iters = len(self.agent_data[0]['position_history'])
        for k in range(max_iters):
            # Compute metrics (same as before)
            true_sigma = np.mean([self.phi_i(self.agent_data[agent_id]['state_history'][k]) for agent_id in self.agent_data], axis=0)
            total_cost = sum(
                self.agent_data[agent_id]['cost_history'][k]
                for agent_id in self.agent_data
            )
            total_grad_norm = np.linalg.norm(sum(self.agent_data[agent_id]['grad_history'][k] for agent_id in self.agent_data))
            total_sigma_error = sum(
                np.linalg.norm(self.agent_data[agent_id]['sigma_history'][k] - true_sigma)
                for agent_id in self.agent_data
            )

            self.cost_history.append(total_cost)
            self.grad_norm_history.append(total_grad_norm)
            self.sigma_error_history.append(total_sigma_error)

    def visualize_results(self):
        """Create plots with correct agent-target pairing"""
        sorted_ids = sorted(self.agent_data.keys())  # Fix: Sort agent IDs
        
        # 1. Plot optimization metrics
        plt.figure(figsize=(18, 5))
        
        plt.subplot(1, 3, 1)
        plt.semilogy(self.cost_history)
        plt.title('Total Cost (Log Scale)')
        plt.xlabel('Iteration')
        plt.ylabel('Cost')
        plt.grid(True)
        
        plt.subplot(1, 3, 2)
        plt.semilogy(self.grad_norm_history)
        plt.title('Total Gradient Norm (Log Scale)')
        plt.xlabel('Iteration')
        plt.ylabel('Gradient Norm')
        plt.grid(True)
        
        plt.subplot(1, 3, 3)
        plt.semilogy(self.sigma_error_history)
        plt.title('Sigma Estimation Error (Log Scale)')
        plt.xlabel('Iteration')
        plt.ylabel('Error')
        plt.grid(True)
        
        plt.tight_layout()
        plt.show()
        
        # 2. Plot final positions with sorted IDs
        final_positions = [self.agent_data[a]['position_history'][-1] for a in sorted_ids]
        targets = [self.agent_data[a]['target'] for a in sorted_ids]
        final_sigma = np.mean(final_positions, axis=0)
        
        plt.figure(figsize=(10, 8))
        
        # Plot targets (T0, T1, ...)
        plt.scatter([t[0] for t in targets], [t[1] for t in targets], 
                   c='blue', s=100, label='Targets')
        for i, target in enumerate(targets):
            plt.text(target[0], target[1], f'T{i}', ha='center', va='center', color='white')
        
        # Plot agents (A0, A1, ...)
        plt.scatter([p[0] for p in final_positions], [p[1] for p in final_positions], 
                   c='red', s=100, label='Agents')
        for i, pos in enumerate(final_positions):
            plt.text(pos[0], pos[1], f'A{i}', ha='center', va='center', color='white')
            plt.plot([pos[0], targets[i][0]], [pos[1], targets[i][1]], 'b--', alpha=0.3)
        
        # Plot fleet centroid
        plt.scatter(final_sigma[0], final_sigma[1], 
                   c='purple', s=200, marker='s', label='Fleet Centroid')
        
        plt.xlabel('X coordinate')
        plt.ylabel('Y coordinate')
        plt.grid(True)
        plt.legend()
        plt.title('Final Positions with Targets and Centroid')
        plt.axis('equal')
        plt.show()
        
        # 3. Create animation with sorted IDs
        self.create_animation(sorted_ids)
    
    def create_animation(self, sorted_ids):
        """Animate with correct agent-target pairs"""
        fig, ax = plt.subplots(figsize=(10, 8))
        ax.set_xlim(0, 10)
        ax.set_ylim(0, 10)
        ax.grid(True)
        ax.set_title('Multi-Robot Aggregative Optimization')
        
        # Create target markers
        targets = [self.agent_data[a]['target'] for a in sorted_ids]
        for i, target in enumerate(targets):
            ax.scatter(target[0], target[1], c='blue', s=100)
            ax.text(target[0], target[1], f'T{i}', ha='center', va='center', color='white')
        
        # Create agent elements in ID order
        agent_dots = []
        agent_labels = []
        target_lines = []
        bary_lines = []
        
        for i in range(len(sorted_ids)):
            # Agent markers
            dot = ax.scatter([], [], c='red', s=100, label=f'Agent {i}' if i == 0 else None)
            label = ax.text(0, 0, f'A{i}', ha='center', va='center', color='white')
            agent_dots.append(dot)
            agent_labels.append(label)
            
            # Lines to targets
            line1, = ax.plot([], [], 'b--', alpha=0.3)
            target_lines.append(line1)
            
            # Lines to barycenter
            line2, = ax.plot([], [], 'm:', alpha=0.3)
            bary_lines.append(line2)
        
        # Barycenter marker
        bary_center = ax.scatter([], [], c='purple', s=200, marker='s', label='Fleet Barycenter')
        ax.legend()
        
        def update(frame):
            current_positions = []
            for i, agent_id in enumerate(sorted_ids):
                if frame < len(self.agent_data[agent_id]['position_history']):
                    pos = self.agent_data[agent_id]['position_history'][frame]
                    agent_dots[i].set_offsets([pos])
                    agent_labels[i].set_position(pos)
                    target_lines[i].set_data([pos[0], targets[i][0]], [pos[1], targets[i][1]])
                    current_positions.append(pos)
            
            # Update barycenter
            if current_positions:
                current_bary = np.mean(current_positions, axis=0)
                bary_center.set_offsets([current_bary])
                for i, pos in enumerate(current_positions):
                    bary_lines[i].set_data([pos[0], current_bary[0]], [pos[1], current_bary[1]])
            
            return (*agent_dots, *agent_labels, bary_center, *target_lines, *bary_lines)
        
        max_frames = max(len(self.agent_data[a]['position_history']) for a in sorted_ids)
        self.animation = FuncAnimation(fig, update, frames=max_frames, interval=50, blit=True)
        plt.show()

    def phi_i(self, z_i): return np.array(z_i, dtype=float)


def main(args=None):
    rclpy.init(args=args)
    visualization_node = VisualizationNode()
    rclpy.spin(visualization_node)
    visualization_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()