import rclpy
from rclpy.node import Node
from visualization_msgs.msg import Marker, MarkerArray
from std_msgs.msg import Float32MultiArray as MsgFloat
import numpy as np

class GenericVisualizer(Node):
    def __init__(self):
        super().__init__('generic_visualizer')
        self.agent_positions = {}
        self.agent_targets = {}
        self.barycenter_history = []
        
        self.subscription = self.create_subscription(
            MsgFloat,
            '/visualization_data',
            self.listener_callback,
            10
        )
        
        self.marker_pub = self.create_publisher(MarkerArray, '/visualization_markers', 10)
        self.timer = self.create_timer(0.1, self.publish_markers)  # 10Hz update

    def listener_callback(self, msg):
        agent_id = int(msg.data[0])
        # Extract position (indices 2-3)
        position = [float(msg.data[2]), float(msg.data[3])]
        # Extract target (indices 10-11)
        target = [float(msg.data[10]), float(msg.data[11])]
        
        self.agent_positions[agent_id] = position
        self.agent_targets[agent_id] = target
        
        # Calculate barycenter
        if self.agent_positions:
            positions = np.array(list(self.agent_positions.values()))
            barycenter = np.mean(positions, axis=0)
            self.barycenter_history.append(barycenter)

    def publish_markers(self):
        marker_array = MarkerArray()
        
        # Agent markers (red spheres)
        for agent_id, position in self.agent_positions.items():
            marker = Marker()
            marker.header.frame_id = "map"
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.ns = f"agent_{agent_id}"
            marker.id = 0
            marker.type = Marker.SPHERE
            marker.action = Marker.ADD
            marker.pose.position.x = float(position[0])
            marker.pose.position.y = float(position[1])
            marker.pose.position.z = 0.0
            marker.scale.x = 0.2
            marker.scale.y = 0.2
            marker.scale.z = 0.2
            marker.color.a = 1.0
            marker.color.r = 1.0
            marker.color.g = 0.0
            marker.color.b = 0.0
            marker_array.markers.append(marker)

        # Target markers (green cubes)
        for agent_id, target in self.agent_targets.items():
            marker = Marker()
            marker.header.frame_id = "map"
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.ns = f"target_{agent_id}"
            marker.id = 0
            marker.type = Marker.SPHERE
            marker.action = Marker.ADD
            marker.pose.position.x = float(target[0])
            marker.pose.position.y = float(target[1])
            marker.pose.position.z = 0.0
            marker.scale.x = 0.2
            marker.scale.y = 0.2
            marker.scale.z = 0.2
            marker.color.a = 1.0
            marker.color.r = 0.0
            marker.color.g = 0.0
            marker.color.b = 1.0
            marker_array.markers.append(marker)

        # Barycenter marker (blue sphere)
        if self.barycenter_history:
            barycenter = self.barycenter_history[-1]
            marker = Marker()
            marker.header.frame_id = "map"
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.ns = "barycenter"
            marker.id = 0
            marker.type = Marker.CUBE
            marker.action = Marker.ADD
            marker.pose.position.x = float(barycenter[0])
            marker.pose.position.y = float(barycenter[1])
            marker.pose.position.z = 0.0
            marker.scale.x = 0.2
            marker.scale.y = 0.2
            marker.scale.z = 0.2
            marker.color.a = 1.0
            marker.color.r = 0.5
            marker.color.g = 0.0
            marker.color.b = 0.5
            marker_array.markers.append(marker)

        self.marker_pub.publish(marker_array)

def main(args=None):
    rclpy.init(args=args)
    visualizer = GenericVisualizer()
    rclpy.spin(visualizer)
    visualizer.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()