from launch import LaunchDescription
from launch_ros.actions import Node
import numpy as np
import networkx as nx
from scipy import sparse  # Explicit import for sparse module
import os
from ament_index_python.packages import get_package_share_directory
from launch.actions import TimerAction


class Agent_Config:
    def __init__(self, id, position):
        self.id = int(id)  # Force native int
        self.position = np.array(position, dtype=float).astype(float)  # Force float64->float
        self.target = None
        self.state = None
        self.sigma_estimate = np.array([], dtype=float).astype(float)
        self.v_estimate = np.array([])
        self.neighbors = []
        self.weights = {}
        self.history = []
        self.gamma = 1.0
        self.dimension = None

    def set_target(self, target_position):
        self.target = np.array(target_position, dtype=float)

    def set_gamma(self, gamma):
        self.gamma = gamma

class AggregativeSetup:
    def __init__(self, agents, dimension, graph_type='erdos_renyi', p_er=0.8):
        self.agents = agents
        self.num_agents = len(agents)
        self.dimension = dimension  # Working in 2D space
        
        # First ensure all states are properly initialized
        for agent in self.agents:
            agent.state = np.array(agent.position, dtype=float)
            agent.history = [agent.position.copy()]
            agent.dimension = self.dimension
            # Initialize sigma_estimate and v_estimate as zero arrays
            agent.sigma_estimate = np.zeros(self.dimension, dtype=float)
            agent.v_estimate = np.zeros(self.dimension, dtype=float)
        
        # Create communication graph
        self.create_communication_graph(graph_type, p_er)
    
    def create_communication_graph(self, graph_type, p_er):
        """Create a connected communication graph between agents with a doubly stochastic matrix"""
        if graph_type == 'erdos_renyi':
            while True:
                G = nx.erdos_renyi_graph(self.num_agents, p_er)
                if nx.is_connected(G):
                    break
            Adj = nx.adjacency_matrix(G).toarray()
        elif graph_type == 'cycle':
            G = nx.cycle_graph(self.num_agents)
            Adj = nx.adjacency_matrix(G).toarray()
        else:
            G = nx.complete_graph(self.num_agents)
            Adj = nx.adjacency_matrix(G).toarray()
        
        # Metropolis-Hastings weights
        degrees = np.sum(Adj, axis=1)
        A = np.zeros((self.num_agents, self.num_agents))
        for i in range(self.num_agents):
            neighbors = np.nonzero(Adj[i])[0]
            for j in neighbors:
                if i < j:
                    max_deg = max(degrees[i], degrees[j])
                    weight = 1 / (1 + max_deg)
                    A[i, j] = weight
                    A[j, i] = weight
            A[i, i] = 1 - np.sum(A[i, :])
        
        self.A = A
        
        # Store neighbors and weights
        for i, agent in enumerate(self.agents):
            agent.neighbors = list(np.nonzero(Adj[i])[0])
            agent.weights = {int(j): float(A[i, j]) for j in agent.neighbors}  # Double conversion
            agent.weights[int(i)] = float(A[i, i])  # Self-weight

def generate_launch_description():
    np.random.seed(42)
    dimension = 2  # Problem dimension
    num_agents = 8 # Number of agents
    area_size = 10 # Area size of the problem

    step_size = 0.01
    MAXITERS = 977
    COMM_TIME = 1e-1  # communication time period

    # Create agents with random initial positions
    agents = [Agent_Config(i, np.random.uniform(0, area_size, size=2)) for i in range(num_agents)]
    
    # Assign private targets
    for agent in agents:
        agent.set_target(np.random.uniform(0, area_size, size=2))
    
    # Set different gamma values
    for i, agent in enumerate(agents):
        # agent.set_gamma(0.3 + 0.7 * (i % 2))  # Alternate between 0.3 and 1.0
        agent.set_gamma(1.0)  # Alternate between 0.3 and 1.0

    AggregativeSetup(agents, dimension, graph_type='cycle') # Simulation Setup

    node_list = []  # Append here your nodes
    package_name = "aggregative_optimization"

    for i, agent in enumerate(agents):
        node_list.append(
            Node(
                package=package_name,
                namespace=f"agent_{i}",
                executable="generic_agent",
                parameters=[
                    {
                        "id": int(agent.id),  # Convert numpy.int64 to int
                        "position": [float(x) for x in agent.position],  # Convert numpy.float to float
                        "target": [float(x) for x in agent.target],
                        "state": [float(x) for x in agent.state],
                        "sigma_estimate": [float(x) for x in agent.sigma_estimate],
                        "v_estimate": [float(x) for x in agent.v_estimate],
                        "neighbors": [int(n) for n in agent.neighbors],  # Convert numpy.int64 neighbors
                        "weights": [item for pair in agent.weights.items() for item in (int(pair[0]), float(pair[1]))],
                        "gamma": float(agent.gamma),
                        "dimension": int(agent.dimension),
                        "communication_time": COMM_TIME,
                        "maxT": MAXITERS,
                        "step_size": step_size,
                    }
                ],
                output="screen",
                prefix=f'xterm -title "agent_{i}" -fg white -bg black -fs 12 -fa "Monospace" -hold -e',
            )
        )

    node_list.append(
        Node(
            package=package_name,
            executable='visualization_node',
            output='screen'
        )
    )

    # Add visualizer node
    node_list.append(
        Node(
            package=package_name,
            executable='generic_visualizer',
            output='screen'
        )
    )

    # Add RViz node
    rviz_config_dir = get_package_share_directory(package_name)
    rviz_config_file = os.path.join(rviz_config_dir,'rviz_config.rviz')
    node_list.append(
        TimerAction(
            period=0.5,
            actions=[
                Node(
                    package='rviz2',
                    executable='rviz2',
                    arguments=['-d', rviz_config_file],
                    output='screen'
                )
            ]
        )
    )

    return LaunchDescription(node_list)