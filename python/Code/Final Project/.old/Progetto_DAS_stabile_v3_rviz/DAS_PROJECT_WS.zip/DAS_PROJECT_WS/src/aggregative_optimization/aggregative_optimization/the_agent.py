# This script implements a ROS 2 node for an agent in a distributed aggregative optimization system.

#Import necessary libraries
import numpy as np # Numpy for numerical operations
import rclpy # ROS 2 Python client library for creating nodes and handling communication
from rclpy.node import Node # Node class for creating ROS 2 nodes
from std_msgs.msg import Float32MultiArray as MsgFloat # Message type for publishing and subscribing to float arrays
import time # Time module for handling delays and timeouts
from typing import Dict, List, Optional # Type hints for better code clarity and type checking

class Agent(Node):
    """ Agent node for aggregative optimization in a distributed system.
    This agent performs optimization based on received messages from neighbors,
    updating its state, and communicating results back to neighbors.
    """
    def __init__(self):
        """Initialize the agent with parameters and communication setup."""
        super().__init__( # Initialize the ROS 2 node
            "aggregative_optimization_agent", # Node name 
            allow_undeclared_parameters=True, # Allow the node to accept parameters from the launch file (or CLI) even if not explicitly declared in code
            automatically_declare_parameters_from_overrides=True, # Automatically declare parameters passed via launch file (or CLI) without manual declaration
        )

        # Get parameters from the launch file aggregative_optimization_launch.py
        self.id = int(self.get_parameter("id").value)  # Unique identifier for the agent
        self.dimension = int(self.get_parameter("dimension").value) # Robot position variable dimension (2D space)
        self.gamma = float(self.get_parameter("gamma").value) # Tradeoff parameter for the local cost function (γ_i)
        self.communication_time = float(self.get_parameter("communication_time").value) # communication time period
        self.maxT = int(self.get_parameter("maxT").value) # Maximum number of iterations for the optimization algorithm
        self.step_size = float(self.get_parameter("step_size").value) # Step size for the optimization algorithm
        self.max_wait_cycles = 5  # Max cycles to wait for late messages

        # Inizialization of the agent attributes with safe array conversion getting the parameters from the launch file
        self.position = self._safe_array_conversion("position", self.dimension)  # Current position of the agent (z_i)
        self.target = self._safe_array_conversion("target", self.dimension) # Private target (r_i)
        self.state = self._safe_array_conversion("state", self.dimension) # Current state estimate of the agent (z_i)
        self.sigma_estimate = self.phi_i(self.state)  # Initial estimate of agent i of σ(z) (s_i_0) set to ϕ_i(z_i_0) 
        self.v_estimate = self.gradient_2_cost(self.state, self.sigma_estimate)  # Initial estimate of (1/N)*∑∇₂ℓ_j(z_j,σ) set to ∇₂ℓ_i(z_i_0, ϕ_i(z_i_0))
        
        # Communication setup getting the parameters from the launch file
        self.neighbors = [int(n) for n in self.get_parameter("neighbors").value]  # Get neighbors (indices) of agent i (non-zero entries of row i in the adjacency matrix). Note that this does not include self-loops.
        self.weights = self._process_weights() # Get weights of agent i (including self weight) by processing the weights parameter from the launch file
        self._setup_communication() # Setup communication channels for publishing and subscribing to messages

        # Tracking variables 
        self.k = 0 # Current iteration of the optimization algorithm
        self.wait_cycles = 0 # Counter for waiting cycles when messages are missing
        self.last_received_iter = {j: -1 for j in self.neighbors} # Track last received iteration for each neighbor
        self.received_messages: Dict[int, Dict[int, List[float]]] = {}  # {neighbor: {iter: data}} # Track received messages by neighbor and iteration
        self.last_known_state: Dict[int, np.ndarray] = {}  # {neighbor: state} Track neighbors' last state 
        self.last_known_sigma: Dict[int, np.ndarray] = {}  # {neighbor: sigma estimate} Track neighbors' last sigma estiamate 
        self.last_known_v: Dict[int, np.ndarray] = {}  # {neighbor: v} Track neighbors' last v 

    def _safe_array_conversion(self, param_name: str, expected_length: int) -> np.ndarray:
        """Convert parameter to numpy array with validation for expected length.
        Args:
            param_name (str): Name of the parameter to convert.
            expected_length (int): Expected length of the parameter value.
        Returns:
            np.ndarray: Numpy array of the parameter value.
        Raises:
            ValueError: If the parameter value is not a list or does not match the expected length.
        """
        param_value = self.get_parameter(param_name).value # Get the parameter value from the launch file
        if not isinstance(param_value, list) or len(param_value) != expected_length: # Validate the parameter value by checking if it is a list and has the expected length
            raise ValueError(f"Invalid {param_name} parameter") # Raise an error if the parameter value is not valid
        return np.array([float(x) for x in param_value], dtype=float) # Convert the parameter value to a numpy array of floats if it is valid

    def _process_weights(self) -> Dict[int, float]:
        """Process weights into neighbor->weight mapping
        Args:
            None
        Returns:
            Dict[int, float]: Dictionary mapping neighbor IDs to their weights.
        """
        weights_list = self.get_parameter("weights").value # Get the weights parameter from the launch file
        weights = { # Convert the weights list into a dictionary mapping neighbor IDs to their weights
            int(weights_list[i]): float(weights_list[i+1]) 
            for i in range(0, len(weights_list), 2) 
        } 
        weights.setdefault(self.id, 1.0 - sum(w for j, w in weights.items() if j != self.id)) # Ensure self weight is set to 1 - sum of neighbors' weights
        return weights # Return the processed weights dictionary

    def _setup_communication(self):
        """Initialize all communication channels for publishing and subscribing."""
        # Agent i creates a unique publisher on /topic_i to broadcast its messages that will be received/subscribed by its neighbors
        self.publisher = self.create_publisher(MsgFloat, f"/topic_{self.id}", 10)  
        
        # Agent i subscribes to each of its neighbors' topics (/topic_j)
        # This allows it to receive messages from neighboring agents
        for j in self.neighbors: # Iterate over each neighbor
            self.create_subscription( # Create a subscription for each neighbor
                MsgFloat, # Message type for receiving float arrays
                f"/topic_{j}", # Topic name for the neighbor j
                lambda msg, j=j: self.listener_callback(msg, j), # Callback function (triggered when a message is received) to handle the message. lambda is used to capture the neighbor ID j in the callback
                10 # Quesue size for the subscription
            )
        # # Agent i creates a publisher for sending visualization data to be subscribed by the visualization node
        self.vis_publisher = self.create_publisher(MsgFloat, '/visualization_data', 10) 
        # Create a timer that calls the `timer_callback` method every `communication_time` seconds (it will be used to trigger the optimization loop, publish state and visualization data)
        self.timer = self.create_timer(self.communication_time, self.timer_callback) 

    def listener_callback(self, msg: MsgFloat, neighbor_id: int):
        """Store messages from neighbors with iteration tracking and update last known values.
        Args:
            msg (MsgFloat): The received message containing data from a neighbor.
            neighbor_id (int): The ID of the neighbor that sent the message.
        """
        msg_iter = int(msg.data[0]) # Extract the iteration number from the message
        data = list(msg.data[1:]) # Extract the actual data from the message (excluding the iteration number) 
        
        # Update last known values
        self.last_known_state[neighbor_id] = np.array(data[:self.dimension]) # Store the last known state of the neighbor j
        self.last_known_sigma[neighbor_id] = np.array(data[self.dimension:2*self.dimension]) # Store the last known sigma estimate of the neighbor j
        self.last_known_v[neighbor_id] = np.array(data[2*self.dimension:3*self.dimension]) # Store the last known v of the neighbor j
        
        # Store by iteration
        if neighbor_id not in self.received_messages:  # If the neighbor is not already in the received messages dictionary
            self.received_messages[neighbor_id] = {} # Initialize an empty dictionary for the neighbor j
        self.received_messages[neighbor_id][msg_iter] = data # Store the message data of the neighbor j for the iteration msg_iter

    def timer_callback(self):
        """Main optimization loop with syncronization handling."""
        if self.k == 0: # Initial iteration
            self._publish_state() # Publish inittial iteration, state, sigma estimate, and v
            self.k += 1 # Increment iteration counter
            return # Early return to exit the method to avoid unnecessary processing on the first iteration (to allow neighbors to initialize)

        # Check for k-1 messages since this is the expected iteration for the optimization step
        expected_iter = self.k - 1 # Expected iteration for the optimization step
        ready, missing = self._check_messages_ready(expected_iter) # Check if all neighbors have messages for expected_iter
        # ready is true if all neighbors have sent messages for expected_iter, otherwise false
        # missing is a list of neighbors that are missing messages for expected_iter
        
        if not ready: # If not all messages from neighbors are ready for expected_iter
            self.wait_cycles += 1 # Increment the waiting counter
            if self.wait_cycles <= self.max_wait_cycles: # If within the maximum wait cycles
                if self.wait_cycles == 1: # Print debug message only on first wait cycle
                    self.get_logger().debug( # Debug message to indicate waiting for messages
                        f"Agent {self.id} waiting for {missing} (cycle {self.wait_cycles}/{self.max_wait_cycles})"
                    )
                return # Early return to exit the method to avoid proceeding with optimization step if messages are not ready 
            else: # If maximum wait cycles exceeded proceed with optimization step, publish state, estimates and visualization data
                self.get_logger().warning(  # Warning message to indicate proceeding without expected data from neighbors from expected_iter
                    f"Agent {self.id} proceeding without expected iter {expected_iter} of agent {missing} after {self.max_wait_cycles} waits"
                )

        # Reset waiting counter if proceeding
        self.wait_cycles = 0
        
        try: 
            self._optimization_step(expected_iter) # Perform the optimization step using k-1 data as expected or previous if messages are missing after maximum wait cycles
            self._publish_state() # Publish the current iteration, state, sigma estimate, and v
            self._publish_visualization_data() # Publish visualization data for the agent
            self.k += 1 # Increment the iteration counter
        except Exception as e: # Handle any exceptions during the optimization step. The exception is stored in e
            self.get_logger().error(f"Optimization error: {str(e)}") # Log the error message in which the exception stored in e is shown
            raise # Raise the exception to stop the agent if an error occurs. The agent will stop cleanly and the error will be logged

        # Clear old messages (keep only current k and previous iter k-1)  
        for j in self.neighbors: # Iterate over each neighbor
            if j in self.received_messages: # If neighbor j has sent messages at least once
                keep_iters = [self.k, self.k-1] # Keep only the current iteration k and the previous iteration k-1
                self.received_messages[j] = { # Update the received messages for neighbor j to keep only the specified iterations
                    k: v for k, v in self.received_messages[j].items() # Keep only messages for iterations k and k-1 if they are in keep_iters
                    if k in keep_iters
                }

        if self.k > self.maxT: # If the maximum number of iterations of the optimization algorithm is reached
            self._terminate() # Terminate the agent by publishing final message and shutting down

    def _check_messages_ready(self, expected_iter: int) -> tuple[bool, list[int]]:
        """Check if all neighbors have messages for expected_iter.
        Args:
            expected_iter (int): The expected iteration number for which messages should be received.
        Returns:
            tuple[bool, list[int]]: A tuple where the first element is a boolean indicating
            if all messages are ready, and the second element is a list of neighbors that are missing messages.
        """
        missing = [] # List to track neighbors that are missing messages for the expected iteration
        for j in self.neighbors: # Iterate over each neighbor
            if j not in self.received_messages or expected_iter not in self.received_messages[j]: # If neighbor j has never sent a message or has not sent a message for the expected iteration
                missing.append(j) # Add neighbor j to the missing list
        return (len(missing) == 0, missing) # Return True if no neighbors are missing messages, otherwise return False and the list of missing neighbors

    def _optimization_step(self, expected_iter: int):
        """Synchronous optimization step using k-1 data from neighbors.
        Args:
            expected_iter (int): The expected iteration number for which messages should be received.
        """
        prev_state = self.state.copy() # Store the previous state before updating
        prev_sigma = self.sigma_estimate.copy() # Store the previous sigma estimate before updating

        # Collect neighbor data from expected_iter or last known
        neighbor_data = {} # Dictionary to store data from neighbors for the expected iteration or last known 
        for j in self.neighbors: # Iterate over each neighbor
            if j in self.received_messages and expected_iter in self.received_messages[j]: # If neighbor j has sent a message for the expected iteration
                neighbor_data[j] = self.received_messages[j][expected_iter] # Store the message data for neighbor j from the expected iteration
            else: # If neighbor j has not sent a message for the expected iteration
                # Fallback to last known values
                neighbor_data[j] = [ # Use last known values if available, otherwise use zeros
                    *self.last_known_state.get(j, np.zeros(self.dimension)), # Last known state of neighbor j or zeros if not available
                    *self.last_known_sigma.get(j, np.zeros(self.dimension)), # Last known sigma estimate of neighbor j or zeros if not available
                    *self.last_known_v.get(j, np.zeros(self.dimension)), # Last known v of neighbor j or zeros if not available
                ]

        # State update (z_i) 
        grad_term = ( # Local gradient term for the agent
            self.gradient_1_cost(self.state, self.sigma_estimate) + # ∇₁ℓ_i(z_i, s_i)
            self.gradient_phi(self.state) @ self.v_estimate # ∇ϕ_i(z_i) * v_i
        )
        self.state -= self.step_size * grad_term # Update the agent's state (z_i) using gradient descent
        self.position = self.state.copy() # Update the agent's position (z_i) to the new state

        # Sigma estimate update (s_i)
        new_sigma = self.weights[self.id] * self.sigma_estimate # Start with the term related to the agent itself
        for j in self.neighbors: # Iterate over each neighbor of the agent
            j_sigma = np.array(neighbor_data[j][self.dimension:2*self.dimension]) # Extract the sigma estimate of neighbor j
            new_sigma += self.weights[j] * j_sigma # Add the weighted sigma estimates of neighbors
        new_sigma += self.phi_i(self.state) - self.phi_i(prev_state) # Add the innovation term
        self.sigma_estimate = new_sigma # Update the agent's sigma estimate (s_i)

        # v estimate update (v_i) 
        new_v = self.weights[self.id] * self.v_estimate # Start with the term related to the agent itself
        for j in self.neighbors: # Iterate over each neighbor of the agent
            j_v = np.array(neighbor_data[j][2*self.dimension:3*self.dimension]) # Extract the v estimate of neighbor j
            new_v += self.weights[j] * j_v # Add the weighted v estimates of neighbors
        new_v += ( # Add the innovation term
            self.gradient_2_cost(self.state, self.sigma_estimate) - 
            self.gradient_2_cost(prev_state, prev_sigma)
        )
        self.v_estimate = new_v # Update the agent's v (v_i)

    def _publish_state(self):
        """Agent i publishes its current iteration, state, sigma estimate, and v on its topic to be received by its neighbors."""
        msg = MsgFloat() # Create a new message to publish
        msg.data = [float(self.k), *self.state, *self.sigma_estimate, *self.v_estimate] # Prepare the message data with the current iteration, state, sigma estimate, and v
        self.publisher.publish(msg) # Publish the message to the topic /topic_i of agent i

    def _publish_visualization_data(self):
        """Publish visualization data to be used by the visualization node."""
        vis_msg = MsgFloat() # Create a new message for visualization data
        vis_msg.data = [ 
            float(self.id), # Agent ID
            float(self.k), # Current iteration
            *self.position, # Current position (z_i)
            *self.state, # Current state estimate (z_i)
            *self.sigma_estimate, # Current sigma estimate (s_i)
            *self.v_estimate, # Current v (v_i)
            *self.target, # Target position (r_i)
            float(self.cost_function(self.state, self.sigma_estimate)), # Local cost function value (ℓ_i(z_i, s_i))
            *(self.gradient_1_cost(self.state, self.sigma_estimate) + self.gradient_phi(self.state) @ self.v_estimate) # local gradient term (∇₁ℓ_i(z_i, s_i) + ∇ϕ_i(z_i) * v_i)
        ]
        self.vis_publisher.publish(vis_msg) # Publish the visualization message to the /visualization_data topic

    def _terminate(self):
        """Handle termination of the agent after reaching max iterations."""
        final_msg = MsgFloat() # Create a final message to indicate completion
        final_msg.data = [-1.0, float(self.k)] # Set the first element to -1.0 to indicate completion and the second element to the current iteration
        self.vis_publisher.publish(final_msg) # Publish the final message to the /visualization_data topic
        self.get_logger().info(f"Agent {self.id} completed optimization") # Log that the agent has completed optimization
        time.sleep(3) # Wait for a few seconds to ensure the final message is processed before shutting down
        raise SystemExit # Raise SystemExit to stop the agent cleanly

    # Mapping function ϕ_i(z_i) = z_i
    def phi_i(self, z_i): return np.array(z_i, dtype=float) 
    # Local cost function ℓ_i(z_i, σ) = γ_i‖z_i - r_i‖² + ‖σ - z_i‖²
    def cost_function(self, z_i, sigma): return self.gamma * np.linalg.norm(z_i - self.target)**2 + np.linalg.norm(sigma - z_i)**2 
    # Gradient of the local cost function with respect to z_i: ∇₁ℓ_i(z_i, σ) = 2γ_i(z_i - r_i) + 2(z_i - σ)
    def gradient_1_cost(self, z_i, sigma): return 2 * self.gamma * (z_i - self.target) + 2 * (z_i - sigma)
    # Gradient of the local cost function with respect to σ: ∇₂ℓ_i(z_i, σ) = 2(σ - z_i)
    def gradient_2_cost(self, z_i, sigma): return 2 * (sigma - z_i)
    # Gradient of the mapping function ϕ_i(z_i) = z_i is the identity matrix: ∇ϕ_i(z_i) = I
    def gradient_phi(self, z_i): return np.eye(self.dimension)

def main(args=None):
    rclpy.init(args=args)  # Initialize the ROS 2 Python client library with optional command line arguments
    agent = Agent()  # Create an instance of the Agent node
    
    try:
        agent.get_logger().info(f"Agent {agent.id} initializing...")  # Log an informational message indicating the agent i is starting up
        # time.sleep(1 + agent.id * 0.1)  # (commented out) Optional staggered startup delay based on agent ID to avoid startup conflicts
        time.sleep(1)  # Pause execution for 1 second (fixed startup delay, not staggered)
        rclpy.spin(agent)  # Enter a loop that keeps the node alive and processing callbacks until shutdown
    except (SystemExit, KeyboardInterrupt):  # Catch system exit and keyboard interrupt exceptions to handle graceful shutdown
        agent.get_logger().info("Shutting down...")  # Log that the agent is shutting down
    finally:
        agent.destroy_node()  # Clean up and destroy the ROS 2 node instance
        rclpy.shutdown()  # Shutdown the ROS 2 client library, cleaning up resources

if __name__ == "__main__":
    main()  # Call the main function when this script is executed directly