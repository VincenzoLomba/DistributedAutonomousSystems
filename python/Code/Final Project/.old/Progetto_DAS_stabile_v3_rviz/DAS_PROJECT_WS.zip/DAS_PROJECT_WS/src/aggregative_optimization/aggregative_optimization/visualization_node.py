# This script implements a ROS 2 node for visualizing data from agents in a distributed aggregative optimization system.

# Import necessary libraries
import rclpy # ROS 2 Python client library
from rclpy.node import Node # Node class for ROS 2
from std_msgs.msg import Float32MultiArray as MsgFloat # Message type for visualization data
import numpy as np # NumPy for numerical operations
import matplotlib.pyplot as plt # Matplotlib for plotting
from matplotlib.animation import FuncAnimation # FuncAnimation for creating animations

class VisualizationNode(Node):
    """Node for visualizing data from agents in a distributed aggregative optimization system."""
    def __init__(self):
        """Initialize the visualization node."""
        super().__init__('visualization_node') # Initialize the ROS 2 node with the name 'visualization_node'
        
        # Data storage
        self.agent_data = {} # Dictionary to store data for each agent. # {agent_id: {position_history: [], target: [], state_history: [], sigma_history: [], v_history: [], cost_history: [], grad_history: []}}
        self.cost_history = [] # List to store total cost history across iterations
        self.grad_norm_history = [] # List to store total gradient norm history across iterations
        self.sigma_error_history = [] # List to store sigma estimation error history across iterations
        self.max_iters = 0 # Maximum number of iterations observed
        self.num_agents = 0 # Number of agents observed
        self.dimension = 2  # Robot position variable dimension (2D space)
        
        # The visualization node subscribes to the '/visualization_data' topic filled by agents
        self.subscription = self.create_subscription( # Subscribe to the '/visualization_data' topic
            MsgFloat, # Message type for visualization data
            '/visualization_data', # Topic name to subscribe to
            self.listener_callback, # Callback function to handle incoming messages
            10 # QoS (Quality of Service) profile, 10 is the depth of the message queue
        )
        
        # Plotting variables
        self.fig = None # Figure object for plotting
        self.animation = None # Animation object for creating animations
        
    def listener_callback(self, msg):
        """Callback function to handle incoming messages from agents
        Args:
            msg (MsgFloat): The message containing data from an agent.
        """
        agent_id = int(msg.data[0]) # Extract agent ID from the message
        iteration = int(msg.data[1]) # Extract iteration number from the message
        
        if agent_id == -1: # TO BE CORRECTED!!!!  
            self.compute_metrics()
            self.visualize_results()
            return
            
        if agent_id not in self.agent_data: 
            self.agent_data[agent_id] = {
                'position_history': [],
                'target': None,
                'state_history': [],
                'sigma_history': [],
                'v_history': [],
                'cost_history': [],
                'grad_history': []
            }
            self.num_agents = len(self.agent_data)
        
        # Parse the message data
        idx = 2 # Start parsing after agent_id and iteration
        position = np.array(msg.data[idx:idx+self.dimension]) # Extract position data  (z_i) from the message
        idx += self.dimension # Move index forward by the dimension size
        state = np.array(msg.data[idx:idx+self.dimension]) # Extract state data  (z_i) from the message
        idx += self.dimension # Move index forward by the dimension size
        sigma_estimate = np.array(msg.data[idx:idx+self.dimension]) # Extract sigma estimate (s_i) from the message
        idx += self.dimension # Move index forward by the dimension size
        v_estimate = np.array(msg.data[idx:idx+self.dimension]) # Extract v from the message
        idx += self.dimension # Move index forward by the dimension size
        target = np.array(msg.data[idx:idx+self.dimension]) # Extract target position (r_i) from the message
        idx += self.dimension # Move index forward by the dimension size
        cost = msg.data[idx] # Extract local cost function value (ℓ_i(z_i, s_i)) from the message 
        idx += 1 # Move index forward by 1 
        grad = np.array(msg.data[idx:idx+self.dimension]) # Extract local gradient term (∇₁ℓ_i(z_i, s_i) + ∇ϕ_i(z_i) * v_i) from the message
        
        # Store data for the agent in the agent_data dictionary
        agent = self.agent_data[agent_id] # Store the agent's data in a variable according to its ID
        agent['position_history'].append(position) # Append the position to the agent's position history
        agent['state_history'].append(state) # Append the state to the agent's state history
        agent['sigma_history'].append(sigma_estimate) # Append the sigma estimate to the agent's sigma history
        agent['v_history'].append(v_estimate) # Append the v estimate to the agent's v history
        agent['target'] = target # Store the target position for the agent
        agent['cost_history'].append(cost) # Append the local cost function value to the agent's cost history
        agent['grad_history'].append(grad) # Append the local gradient term to the agent's gradient history
    
    def compute_metrics(self):
        max_iters = len(self.agent_data[0]['position_history'])
        for k in range(max_iters):
            # Compute metrics for convergence analysis
            true_sigma = np.mean([self.phi_i(self.agent_data[agent_id]['state_history'][k]) for agent_id in self.agent_data], axis=0) # True barycenter σ(z) as the average of all agents' states
            total_cost = sum( # Compute total cost summing local costs of all agents
                self.agent_data[agent_id]['cost_history'][k] # ℓ_i(z_i, s_i)
                for agent_id in self.agent_data # Iterate over all agents to sum their local costs
            )


            # Compute total gradient norm
            total_grad_norm = np.linalg.norm(sum(self.agent_data[agent_id]['grad_history'][k] for agent_id in self.agent_data))
            
            # POSSIBLE MODIFICATION!!!!!
            # total_grad_components = [  # Compute gradient components from grad_history[k] for each agent
            #     self.agent_data[agent_id]['grad_history'][k]  # Gradient at iteration k for agent with ID agent_id
            #     for agent_id in self.agent_data  # Iterate over each agent ID
            # ]
            # total_grad = np.concatenate([g.flatten() for g in total_grad_components]) # Concatenate all gradient components into a single vector
            # total_grad_norm = np.linalg.norm(total_grad) # Compute the norm of the total gradient vector

            
            total_sigma_error = sum( # Compute total sigma estimation error
                np.linalg.norm(self.agent_data[agent_id]['sigma_history'][k] - true_sigma) # ‖s_i - σ(z)‖
                for agent_id in self.agent_data # Iterate over each agent to sum their sigma estimation errors
            )

            self.cost_history.append(total_cost) # Append the total cost to the cost history
            self.grad_norm_history.append(total_grad_norm) # Append the total gradient norm to the gradient norm history
            self.sigma_error_history.append(total_sigma_error) # Append the total sigma estimation error to the sigma error history

    def visualize_results(self):
        """Create plots with correct agent-target pairing for optimization results"""
        sorted_ids = sorted(self.agent_data.keys())  # Sort agent IDs for consistent ordering
        
        # 1. Plot optimization metrics
        plt.figure(figsize=(18, 5)) # Create a figure with 3 subplots for cost, gradient norm, and total sigma error
        
        plt.subplot(1, 3, 1) # Plot total cost history 
        plt.semilogy(self.cost_history) # Use logarithmic scale for better visibility
        plt.title('Total Cost (Log Scale)') # # Plot title
        plt.xlabel('Iteration') # X-axis label
        plt.ylabel('Cost') # Y-axis label
        plt.grid(True) # Enable grid for better readability
        
        plt.subplot(1, 3, 2) # Plot total gradient norm history 
        plt.semilogy(self.grad_norm_history) # Use logarithmic scale for better visibility
        plt.title('Total Gradient Norm (Log Scale)') # Plot title
        plt.xlabel('Iteration') # X-axis label
        plt.ylabel('Gradient Norm') # Y-axis label
        plt.grid(True) # Enable grid for better readability
        
        plt.subplot(1, 3, 3) # Plot total sigma estimation error history
        plt.semilogy(self.sigma_error_history) # Use logarithmic scale for better visibility
        plt.title('Sigma Estimation Error (Log Scale)') # Plot title
        plt.xlabel('Iteration') # X-axis label
        plt.ylabel('Error') # Y-axis label
        plt.grid(True) # Enable grid for better readability
        
        plt.tight_layout() # Adjust layout to prevent overlap
        plt.show() # Show the optimization metrics plots
        
        # 2. Plot final positions with sorted IDs
        final_positions = [self.agent_data[a]['position_history'][-1] for a in sorted_ids] # Get final positions of agents
        targets = [self.agent_data[a]['target'] for a in sorted_ids] # Get targets of agents
        final_sigma = np.mean(final_positions, axis=0) # Compute the final barycenter (fleet centroid) as the mean of final positions)
        
        plt.figure(figsize=(10, 8)) # Create a new figure for final positions of agents, targets, and barycenter
        
        # Plot targets (T0, T1, ...)
        plt.scatter([t[0] for t in targets], [t[1] for t in targets], # Plot target positions in blue
                   c='blue', s=100, label='Targets') 
        for i, target in enumerate(targets): # Iterate over targets to label them
            plt.text(target[0], target[1], f'T{i}', ha='center', va='center', color='white') # Add text labels for targets
        
        # Plot agents (A0, A1, ...)
        plt.scatter([p[0] for p in final_positions], [p[1] for p in final_positions], # Plot final positions of agents in red
                   c='red', s=100, label='Agents')
        for i, pos in enumerate(final_positions): # Iterate over final positions to label them
            plt.text(pos[0], pos[1], f'A{i}', ha='center', va='center', color='white') # Add text labels for agents
            plt.plot([pos[0], targets[i][0]], [pos[1], targets[i][1]], 'b--', alpha=0.3) # Draw dashed lines from agents to their targets
        
        # Plot fleet centroid
        plt.scatter(final_sigma[0], final_sigma[1], # Plot fleet centroid in purple
                   c='purple', s=200, marker='s', label='Fleet Centroid')
        
        plt.xlabel('X coordinate') # X-axis label
        plt.ylabel('Y coordinate') # Y-axis label
        plt.grid(True) # Enable grid for better readability
        plt.legend() # Show legend to identify agents, targets, and centroid
        plt.title('Final Positions with Targets and Centroid') # Plot title
        plt.axis('equal') # Set equal aspect ratio for X and Y axes
        plt.show() # Show the final positions plot
        
        # 3. Create animation with sorted IDs
        self.create_animation(sorted_ids) # Animate the agents' movements with correct agent-target pairs
    
    def create_animation(self, sorted_ids):
        """Animate with correct agent-target pairs for visualization
        Args:
            sorted_ids (list): List of sorted agent IDs for consistent ordering.
        """
        fig, ax = plt.subplots(figsize=(10, 8)) # Create a figure and axis for the animation
        ax.set_xlim(0, 10) # Set X-axis limits
        ax.set_ylim(0, 10) # Set Y-axis limits
        ax.grid(True) # Enable grid for better readability
        ax.set_title('Multi-Robot Aggregative Optimization') # Set plot title
        
        # Create target markers
        targets = [self.agent_data[a]['target'] for a in sorted_ids] # Get targets for each agent in sorted order
        for i, target in enumerate(targets): # Iterate over targets to plot them
            ax.scatter(target[0], target[1], c='blue', s=100) # Plot target positions in blue
            ax.text(target[0], target[1], f'T{i}', ha='center', va='center', color='white') # Add text labels for targets
        
        # Create agent elements in ID order
        agent_dots = [] # List to store agent markers
        agent_labels = [] # List to store agent labels
        target_lines = [] # List to store lines from agents to targets
        bary_lines = [] # List to store lines from agents to barycenter
        
        for i in range(len(sorted_ids)): # Iterate over sorted agent IDs to create markers and lines
            # Agent markers
            dot = ax.scatter([], [], c='red', s=100, label=f'Agents' if i == 0 else None) # Create a red dot for each agent
            label = ax.text(0, 0, f'A{i}', ha='center', va='center', color='white') # Create a label for each agent
            agent_dots.append(dot) # Append the agent marker to the list
            agent_labels.append(label) # Append the agent label to the list
            
            # Lines to targets
            line1, = ax.plot([], [], 'b--', alpha=0.3) # Create a dashed line from agent to target
            target_lines.append(line1) # Append the target line to the list
            
            # Lines to barycenter
            line2, = ax.plot([], [], 'm:', alpha=0.3) # Create a dotted line from agent to barycenter
            bary_lines.append(line2) # Append the barycenter line to the list
        
        # Barycenter marker
        bary_center = ax.scatter([], [], c='purple', s=200, marker='s', label='Fleet Barycenter') # Create a purple square marker for the fleet barycenter
        ax.legend() # Show legend to identify agents, targets, and barycenter
        
        def update(frame):
            """Update function for animation frames.
            Args:
                frame (int): Current frame number.
            Returns:
                tuple: Updated scatter objects, labels, barycenter, target lines, and barycenter lines
            """
            current_positions = [] # List to store current positions of agents
            for i, agent_id in enumerate(sorted_ids): # Iterate over sorted agent IDs to update positions
                if frame < len(self.agent_data[agent_id]['position_history']): # Check if the frame is within the position history length
                    pos = self.agent_data[agent_id]['position_history'][frame] # Get the position of the agent at the current frame
                    agent_dots[i].set_offsets([pos]) # Update the agent marker position
                    agent_labels[i].set_position(pos) # Update the agent label position
                    target_lines[i].set_data([pos[0], targets[i][0]], [pos[1], targets[i][1]]) # Update the line from agent to target
                    current_positions.append(pos) # Append the current position to the list for barycenter positions    

            # Update barycenter
            if current_positions: # Check if there are current positions to compute barycenter
                current_bary = np.mean(current_positions, axis=0) # Compute the barycenter as the mean of current positions
                bary_center.set_offsets([current_bary]) # Update the barycenter marker position
                for i, pos in enumerate(current_positions): # Iterate over current positions to update barycenter lines
                    bary_lines[i].set_data([pos[0], current_bary[0]], [pos[1], current_bary[1]]) # Update the line from agent to barycenter

            return (*agent_dots, *agent_labels, bary_center, *target_lines, *bary_lines) # Return updated scatter objects, labels, barycenter, target lines, and barycenter lines
        
        max_frames = max(len(self.agent_data[a]['position_history']) for a in sorted_ids) # Determine the maximum number of frames based on the longest position history among agents
        self.animation = FuncAnimation(fig, update, frames=max_frames, interval=50, blit=True) # Create the animation with the update function, number of frames, and interval between frames
        plt.show() # Show the animation plot

    def phi_i(self, z_i): return np.array(z_i, dtype=float) # Mapping function ϕ_i(z_i) = z_i


def main(args=None): # Main function to initialize and run the visualization node
    rclpy.init(args=args) # Initialize the ROS 2 Python client library
    visualization_node = VisualizationNode() # Create an instance of the VisualizationNode
    rclpy.spin(visualization_node) # Spin the node to keep it active and processing incoming messages
    visualization_node.destroy_node() # Destroy the node when done
    rclpy.shutdown() # Shutdown the ROS 2 Python client library

if __name__ == '__main__': # Check if the script is being run directly
    main() # Run the main function to start the visualization node